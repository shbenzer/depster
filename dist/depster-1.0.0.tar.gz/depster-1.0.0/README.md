# depster
An Easy-To-Use Tool for Creating Detailed a Detailed Dependency Spreadsheet for Projects
